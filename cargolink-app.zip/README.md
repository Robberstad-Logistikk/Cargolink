
# CargoLink App

Dette er første versjon av CargoLink – flåtestyringsappen for gods og transport.

## Kom i gang
1. Installer Expo Go på mobilen din.
2. Kjør `npm install` og `npm start` i prosjektmappen.
3. Skann QR-koden og test appen!
